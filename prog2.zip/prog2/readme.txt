Project 2: Griffin Bishop ~ grbishop

The source code for both phases (1 & 2) lies within the "themodule.c" file.
The source code for both phases tests is in the "tester.c" file.

The /var/log/syslog file was too big to submit to turnin, so the "syslog" file in the
directory contains the last 100 lines of the file. 

Usage:

Do "make" then "sudo insmod themodule.ko" then "./tester" to use.
